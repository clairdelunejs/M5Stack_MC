print("wuwuwuw")
print("wuwuwuw")
